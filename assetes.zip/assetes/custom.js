document.addEventListener('contextmenu', function(event) {
    event.preventDefault();
  });